

module.exports = {
    rules: {
        'no-console': 'off',
		'devel': true,
    },
};

